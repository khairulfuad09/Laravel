
<?php $__env->startSection('container'); ?>
    
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="judulModal">Update Data</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="/dashboard/<?php echo e($user->id); ?>" method="post" enctype="multipart/form-data">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label for="name" class="form-label">Username</label>
                        <input type="text" class="form-control" id="name" placeholder="Username" name="name"
                            value="<?php echo e(old('name', $user->name)); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">email</label>
                        <input type="text" class="form-control" id="email" placeholder="email" name="email"
                            value="<?php echo e(old('email', $user->email)); ?>">
                    </div>
                    <div class="mb-3">
                        
                        <input type="hidden" class="form-control" id="password" placeholder="password" name="password"
                            value="<?php echo e($user->password); ?>">
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><a
                        href="/dashboard">Close</a></button>
                <button type="submit" class="btn btn-primary">Update data</button>
            </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplications_Laravel\laravel1\resources\views/updateuser.blade.php ENDPATH**/ ?>