
<?php $__env->startSection('container'); ?>
    

    <h1>Data User</h1>
    <div class="d-flex flex-direction">
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card m-3" style="width: 18rem;">
                <img src="..." class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">Nomor Plat : <?php echo e($user->plat); ?></h5>
                    <p class="card-text">Nama Motor : <?php echo e($user->nama_motor); ?></p>
                    <p class="card-text">alamat : <?php echo e($user->alamat); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <?php echo e($cars->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Aplications_Laravel\laravel1\resources\views/dashboarduser.blade.php ENDPATH**/ ?>